════════════════════════════════════════════════════════
  ▲ THE TOWER — Proof Receipt
════════════════════════════════════════════════════════

Entry #3 — carved Tue Mar 17 2026 11:37:02 GMT+0000 (Coordinated Universal Time)
Tier: open
SHA-256 of text: 2f0f68faea86dd6eaa64a9e531d310703804bdc399c14cb5009e7535be6c1a92
BITCOIN ANCHOR: confirmed at block 941015 (block hash 0000000000000000000133d0e108ad6754bb4ad438f2aa96937f7131add52acd)

──────────────────────────────────────────────────────
  HOW TO VERIFY THIS RECEIPT
──────────────────────────────────────────────────────

EASIEST — drag this ZIP onto the standalone verifier:

  https://neillgroom.github.io/tower-verifier/

The verifier is open-source, runs entirely in your browser, and
does not depend on The Tower being online. Source code:

  https://github.com/neillgroom/tower-verifier

⚠ SECURITY NOTE: before uploading this ZIP, verify the URL above
matches exactly. The Tower has no control over phishing copies.

──────────────────────────────────────────────────────
  CLI VERIFICATION (works on any machine with the OTS client)
──────────────────────────────────────────────────────

If The Tower and the verifier site are both unreachable, you can
still verify this receipt with the standard OpenTimestamps CLI:

  1. Install opentimestamps-client (pip install opentimestamps-client)
  2. From this folder, run:

       ots verify merkle-root.ots

     OpenTimestamps will contact its public calendars and confirm
     the Merkle root is anchored to a real Bitcoin block.

  3. Cross-check the text:

       printf "%s" "$(cat plaintext.txt)" | sha256sum

     The output must equal: 2f0f68faea86dd6eaa64a9e531d310703804bdc399c14cb5009e7535be6c1a92

  4. Confirm the Merkle root in receipt.json matches the root
     reported by `ots verify` in step 2.

  5. The block number reported by `ots verify` is the timestamp.
     Look up the block on any Bitcoin block explorer (e.g.,
     https://mempool.space/block/941015).

──────────────────────────────────────────────────────
  WHAT EACH FILE IN THIS ZIP DOES
──────────────────────────────────────────────────────

  receipt.json          — Tower's proof receipt. Contains the entry text,
                          hashes, Merkle proof, and Bitcoin anchor info.
                          This is the authoritative source for plaintext;
                          do not rely on any other file in this ZIP for
                          the entry content.
  merkle-root.ots       — OpenTimestamps proof binding the Merkle root
                          to a Bitcoin block. Upgraded (calendar-side)
                          if Tower had time to fetch the upgrade.
  btc-block-header.bin  — 80-byte raw Bitcoin block header. Lets the
                          verifier confirm the OTS attestation without
                          any block-explorer call (fully offline). Only
                          present for confirmed entries.
  ciphertext.bin        — (Only if you opted in) AES-256-GCM ciphertext
                          of your sealed entry. Useless without the
                          decryption key, which The Tower never holds.
  ciphertext-meta.json  — (Only if ciphertext.bin is present) IV +
                          algorithm metadata for decryption.
  README.txt            — This file.

──────────────────────────────────────────────────────
  THE PROMISE
──────────────────────────────────────────────────────

Bitcoin's ledger has run continuously since 2009. As long as anyone,
anywhere, runs a Bitcoin node, the hash above remains mathematically
verifiable. The Tower is one tool that put your declaration on that
chain. Dozens of other tools can verify it — even after The Tower
is gone.

"If it's not in The Tower, you didn't say it."

════════════════════════════════════════════════════════
